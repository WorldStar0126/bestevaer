## Next

This is a [Next.js](https://nextjs.org/) project bootstrapped with [`create-next-app`](https://github.com/vercel/next.js/tree/canary/packages/create-next-app).

First, run the development server:

```bash
npm run dev
# or
yarn dev
```

## CMS

We use [Storyblok](https://app.storyblok.com/#!/me/spaces) as the headless CMS.

- For login credentials, check with Upmost.

## Hosting

Hosting at [Netlify](https://app.netlify.com).

- For login credentials, check with Upmost.