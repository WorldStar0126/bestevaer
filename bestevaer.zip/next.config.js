module.exports = {
  reactStrictMode: true,
  images: {
    domains: ['img2.storyblok.com'],
  }
}
