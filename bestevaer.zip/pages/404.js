export default function Error() {
    return (
        <article></article>
    );
}