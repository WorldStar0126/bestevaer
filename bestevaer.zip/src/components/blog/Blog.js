import React from 'react';

import Page from 'src/components/page/Page';

export default function Blog({ blok }) {
    return (
        <Page blok={blok} />
    );
}