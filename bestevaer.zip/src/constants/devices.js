export const MQ_REGULAR = 768;
export const MQ_WIDE = 1024;