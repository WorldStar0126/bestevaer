export const NAV_MAX_HEIGHT = 124;
export const NAV_MIN_HEIGHT = 38;
export const LOGO_MAX_WIDTH = 90;
export const LOGO_MIN_WIDTH = 25;